import React from 'react'

const Pending = () => {
  return (
    <div>
              <div className="col-md-2">
                    <br />
                    <dt style={{ color: "#62A4A8", marginBottom: "10px" }}><i className='fas fa-dolly-flatbed'></i> &nbsp;Pending</dt><br />
                    <div className="card">
                        <div className="card-body">
                            <button type="button" className="btn btn-outline-secondary btn-sm" style={{ borderColor: "rgba(28, 28, 28, 0.688)", marginBottom: "1px" }}><dt>5</dt> In Stage Lane </button>
                            <button type="button" className="btn btn-outline-secondary btn-sm" style={{ borderColor: "rgba(28, 28, 28, 0.688)" }}><dt>7</dt> Mapped For Entry</button>

                            <br />
                        </div>
                    </div>
                </div>
    </div>
  )
}

export default Pending;
<button type="button" className="btn btn-outline-secondary btn-sm" style={{ borderColor: "rgba(28, 28, 28, 0.688)" }}> <dt>0</dt> Missing </button>