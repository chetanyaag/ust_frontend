import React from 'react'

const Footer = () => {
  return (
    <div>
         <footer class="bottom bg-white">
    <div class="container text-center">
      <p class="my-2">Copyright © 2023 UST All Rights Reserved, visit <a href="www.ust.com">www.ust.com</a> to get in touch</p>
    </div>
  </footer>
    </div>
  )
}

export default Footer;